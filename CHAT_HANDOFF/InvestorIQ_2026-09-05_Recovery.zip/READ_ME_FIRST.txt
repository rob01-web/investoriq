LATEST: Rob approved the prototype visual direction with regular approved fonts. Begin the documented implementation sequence. No hard report page caps. Upload this refreshed ZIP for the immediate fresh-chat transition because the local commits have not been pushed.

InvestorIQ recovery checkpoint - 2026-09-05 UTC
Read CHAT_HANDOFF/03_FRESH_CHAT_PROMPT.md, then the other four canonical files completely.
The cumulative Git patch applies to the verified baseline TREE 830376f89e00f03069fa12a0dd3daf133f3edf19. The local transport commit differs from the remote commit; do not rewrite ancestry.
CHECKPOINT.json records the local commit and tree. No remote push or production action occurred.
The five-page PDF is a visual design prototype, rendered locally with intentionally substituted embedded fonts. It is not the approved full report, actual DocRaptor evidence, or launch certification.
Keep prior archive files intact. Read the September 5 audit checkpoint and prototype README for the exact next step.
